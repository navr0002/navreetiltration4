import React from 'react'

export default function Footer() {
  return (
    <footer style={{ background: '#bdc3c7', padding: '1em', textAlign: 'center', marginTop: '2em' }}>
      <small>&copy; 2025 Game Sale Tracker | Built with ❤️</small>
    </footer>
  )
}
