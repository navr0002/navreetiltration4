import React from 'react'
import { Link } from 'react-router-dom'

export default function Navbar() {
  return (
    <nav style={{ background: '#2c3e50', color: '#ecf0f1', padding: '1em' }}>
      <Link to="/" style={{ color: '#ecf0f1', fontSize: '1.5em', fontWeight: 'bold' }}>
        🎮 Game Sale Manager
      </Link>
    </nav>
  )
}
