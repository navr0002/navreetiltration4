import React, { useState } from 'react'
import { useParams } from 'react-router-dom'
import { useTasks } from '../context/TaskContext'

export default function ListView() {
  const { id } = useParams()
  const { lists, addItem, toggleItem, deleteItem } = useTasks()
  const list = lists.find(l => l.id == id)

  const [task, setTask] = useState('')
  const [priority, setPriority] = useState(1)
  const [showCompleted, setShowCompleted] = useState(true)

  if (!list) return <p>List not found</p>

  const sortedItems = [...list.items].sort((a, b) => a.priority - b.priority)

  return (
    <div style={{ padding: '1em' }}>
      <h2>{list.name}</h2>
      <form onSubmit={e => { e.preventDefault(); addItem(list.id, task, priority); setTask(''); setPriority(1) }}>
        <input value={task} onChange={e => setTask(e.target.value)} placeholder="Task" required />
        <input type="number" value={priority} onChange={e => setPriority(+e.target.value)} min="1" max="5" />
        <button type="submit">Add Item</button>
      </form>
      <label>
        <input type="checkbox" checked={showCompleted} onChange={e => setShowCompleted(e.target.checked)} />
        Show Completed
      </label>
      <ul>
        {sortedItems
          .filter(item => showCompleted || !item.completed)
          .map(item => (
            <li key={item.id}>
              <span style={{ textDecoration: item.completed ? 'line-through' : 'none' }}>{item.task} (Priority: {item.priority})</span>
              <button onClick={() => toggleItem(list.id, item.id)}>Toggle</button>
              <button onClick={() => deleteItem(list.id, item.id)}>Delete</button>
            </li>
        ))}
      </ul>
    </div>
  )
}
