import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { useTasks } from '../context/TaskContext'

export default function Home() {
  const { lists, addList, deleteList } = useTasks()
  const [name, setName] = useState('')

  return (
    <div style={{ padding: '1em' }}>
      <h2>Your Lists</h2>
      <form onSubmit={e => { e.preventDefault(); addList(name); setName('') }}>
        <input value={name} onChange={e => setName(e.target.value)} placeholder="New list name" required />
        <button type="submit">Add List</button>
      </form>
      <ul>
        {lists.map(list => (
          <li key={list.id}>
            <Link to={`/list/${list.id}`}>{list.name}</Link>
            <button onClick={() => deleteList(list.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  )
}
