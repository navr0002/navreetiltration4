import React, { createContext, useContext, useEffect, useState } from 'react'

const TaskContext = createContext()

export function TaskProvider({ children }) {
  const [lists, setLists] = useState(() => {
    const stored = localStorage.getItem('taskLists')
    return stored ? JSON.parse(stored) : []
  })

  useEffect(() => {
    localStorage.setItem('taskLists', JSON.stringify(lists))
  }, [lists])

  const addList = (name) => {
    const newList = { id: Date.now(), name, items: [] }
    setLists([...lists, newList])
  }

  const deleteList = (id) => {
    setLists(lists.filter(list => list.id !== id))
  }

  const addItem = (listId, task, priority) => {
    setLists(lists.map(list => list.id === listId
      ? { ...list, items: [...list.items, { id: Date.now(), task, priority, completed: false }] }
      : list))
  }

  const toggleItem = (listId, itemId) => {
    setLists(lists.map(list => list.id === listId
      ? { ...list, items: list.items.map(item =>
          item.id === itemId ? { ...item, completed: !item.completed } : item) }
      : list))
  }

  const deleteItem = (listId, itemId) => {
    setLists(lists.map(list => list.id === listId
      ? { ...list, items: list.items.filter(item => item.id !== itemId) }
      : list))
  }

  return (
    <TaskContext.Provider value={{ lists, addList, deleteList, addItem, toggleItem, deleteItem }}>
      {children}
    </TaskContext.Provider>
  )
}

export const useTasks = () => useContext(TaskContext)
